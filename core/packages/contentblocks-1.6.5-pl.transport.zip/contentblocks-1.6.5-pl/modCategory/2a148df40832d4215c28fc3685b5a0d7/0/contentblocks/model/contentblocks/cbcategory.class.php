<?php
class cbCategory extends xPDOSimpleObject {}