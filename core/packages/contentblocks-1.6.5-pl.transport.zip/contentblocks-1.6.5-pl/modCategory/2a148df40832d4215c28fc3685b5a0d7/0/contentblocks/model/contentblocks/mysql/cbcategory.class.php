<?php
require_once (dirname(dirname(__FILE__)) . '/cbcategory.class.php');
class cbCategory_mysql extends cbCategory {}