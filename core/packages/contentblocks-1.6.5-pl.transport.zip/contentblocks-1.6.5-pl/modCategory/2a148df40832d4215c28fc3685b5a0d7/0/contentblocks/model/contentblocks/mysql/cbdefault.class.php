<?php
require_once (dirname(dirname(__FILE__)) . '/cbdefault.class.php');
class cbDefault_mysql extends cbDefault {}
